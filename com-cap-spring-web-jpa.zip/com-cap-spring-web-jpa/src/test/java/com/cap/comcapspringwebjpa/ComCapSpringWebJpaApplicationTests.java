package com.cap.comcapspringwebjpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComCapSpringWebJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
