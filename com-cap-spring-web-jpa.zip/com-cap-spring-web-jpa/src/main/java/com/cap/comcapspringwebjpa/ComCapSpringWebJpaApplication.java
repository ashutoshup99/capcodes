package com.cap.comcapspringwebjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComCapSpringWebJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComCapSpringWebJpaApplication.class, args);
	}

}
